package com.leenak0.swurent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class compare_floor_insa extends AppCompatActivity {

    Button com_insa_1f, com_insa_2f, com_insa_3f, com_insa_4f, com_insa_5f, com_insa_6f, com_insa_7f, com_insa_8f, com_insa_9f;
    Button com_f_insa_prev;
    String info_building, info_classroom, sen1, com_building, info_floor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare_floor_insa);

        com_insa_1f = (Button)findViewById(R.id.com_insa_1f);
        com_insa_2f = (Button)findViewById(R.id.com_insa_2f);
        com_insa_3f = (Button)findViewById(R.id.com_insa_3f);
        com_insa_4f = (Button)findViewById(R.id.com_insa_4f);
        com_insa_5f = (Button)findViewById(R.id.com_insa_5f);
        com_insa_6f = (Button)findViewById(R.id.com_insa_6f);
        com_insa_7f = (Button)findViewById(R.id.com_insa_7f);
        com_insa_8f = (Button)findViewById(R.id.com_insa_8f);
        com_insa_9f = (Button)findViewById(R.id.com_insa_9f);
        com_f_insa_prev = (Button)findViewById(R.id.com_f_insa_prev);

        Intent intent = getIntent();
        info_building = intent.getStringExtra("info_building");
        info_floor = intent.getStringExtra("info_floor");
        info_classroom = intent.getStringExtra("info_classroom");
        sen1 = intent.getStringExtra("sen1");
        com_building=intent.getStringExtra("com_building");

        com_insa_1f.setOnClickListener(new View.OnClickListener(){ //1층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_insa.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","1");
                startActivity(intent);
            }
        });

        com_insa_2f.setOnClickListener(new View.OnClickListener(){ //2층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_insa.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","2");
                startActivity(intent);
            }
        });

        com_insa_3f.setOnClickListener(new View.OnClickListener(){ //3층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_insa.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","3");
                startActivity(intent);
            }
        });

        com_insa_4f.setOnClickListener(new View.OnClickListener(){ //4층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_insa.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","4");
                startActivity(intent);
            }
        });

        com_insa_5f.setOnClickListener(new View.OnClickListener(){ //5층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_insa.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","5");
                startActivity(intent);
            }
        });

        com_insa_6f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_insa.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","6");
                startActivity(intent);
            }
        });

        com_insa_7f.setOnClickListener(new View.OnClickListener(){ //7층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_insa.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","7");
                startActivity(intent);
            }
        });

        com_insa_8f.setOnClickListener(new View.OnClickListener(){ //8층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_insa.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","8");
                startActivity(intent);
            }
        });

        com_insa_9f.setOnClickListener(new View.OnClickListener(){ //9층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_insa.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","9");
                startActivity(intent);
            }
        });

        com_f_insa_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
}