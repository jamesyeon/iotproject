package com.leenak0.swurent;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class compare_classroom extends AppCompatActivity {

    Button com_c1, com_c2, com_c3, com_c4, com_c5, com_c6;
    Button com_c_prev;
    String info_building, info_classroom, sen1, com_building, info_floor, com_floor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare_classroom);

        com_c1 = (Button)findViewById(R.id.com_c1);
        com_c2 = (Button)findViewById(R.id.com_c2);
        com_c3 = (Button)findViewById(R.id.com_c3);
        com_c4 = (Button)findViewById(R.id.com_c4);
        com_c5 = (Button)findViewById(R.id.com_c5);
        com_c6 = (Button)findViewById(R.id.com_c6);
        com_c_prev = (Button)findViewById(R.id.com_c_prev);

        Intent intent = getIntent();
        info_building = intent.getStringExtra("info_building");
        info_floor = intent.getStringExtra("info_floor");
        info_classroom = intent.getStringExtra("info_classroom");
        sen1 = intent.getStringExtra("sen1");
        com_building=intent.getStringExtra("com_building");
        com_floor=intent.getStringExtra("com_floor");

        com_c1.setText(com_floor+"01호");
        com_c2.setText(com_floor+"02호");
        com_c3.setText(com_floor+"03호");
        com_c4.setText(com_floor+"04호");
        com_c5.setText(com_floor+"05호");
        com_c6.setText(com_floor+"06호");

        com_c1.setOnClickListener(new View.OnClickListener(){ //1호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_classroom.this, compare.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor",com_floor);
                intent.putExtra("com_classroom", com_c1.getText().toString());
                startActivity(intent);
            }
        });

        com_c2.setOnClickListener(new View.OnClickListener(){ //2호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_classroom.this, compare.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor",com_floor);
                intent.putExtra("com_classroom", com_c2.getText().toString());
                startActivity(intent);
            }
        });

        com_c3.setOnClickListener(new View.OnClickListener(){ //3호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_classroom.this, compare.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor",com_floor);
                intent.putExtra("com_classroom", com_c3.getText().toString());
                startActivity(intent);
            }
        });

        com_c4.setOnClickListener(new View.OnClickListener(){ //4호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_classroom.this, compare.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor",com_floor);
                intent.putExtra("com_classroom", com_c4.getText().toString());
                startActivity(intent);
            }
        });

        com_c5.setOnClickListener(new View.OnClickListener(){ //5호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_classroom.this, compare.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor",com_floor);
                intent.putExtra("com_classroom", com_c5.getText().toString());
                startActivity(intent);
            }
        });

        com_c6.setOnClickListener(new View.OnClickListener(){ //6호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_classroom.this, compare.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor",com_floor);
                intent.putExtra("com_classroom", com_c6.getText().toString());
                startActivity(intent);
            }
        });

        com_c_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
