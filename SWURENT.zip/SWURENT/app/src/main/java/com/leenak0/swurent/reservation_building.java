package com.leenak0.swurent;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

public class reservation_building extends AppCompatActivity {

    Button reserv_50;
    Button reserv_insa;
    Button reserv_2sci;
    Button reserv_b_prev;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation_building);

        reserv_50 = (Button)findViewById(R.id.reserv_50);
        reserv_insa = (Button)findViewById(R.id.reserv_insa);
        reserv_2sci = (Button)findViewById(R.id.reserv_2sci);
        reserv_b_prev = (Button)findViewById(R.id.reserv_b_prev);

        reserv_50.setOnClickListener(new View.OnClickListener(){ //50주년

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_building.this, reservation_floor_50.class);
                intent.putExtra("building_name", "50주년기념관");
                startActivity(intent);
            }
        });

        reserv_insa.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_building.this, reservation_floor_insa.class);
                intent.putExtra("building_name", "인문사회관");
                startActivity(intent);
            }
        });

        reserv_2sci.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_building.this, reservation_floor_2sci.class);
                intent.putExtra("building_name", "제2과학관");
                startActivity(intent);
            }
        });

        reserv_b_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
