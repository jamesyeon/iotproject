package com.leenak0.swurent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class reservation_floor_insa extends AppCompatActivity {

    Button reserv_insa_1f, reserv_insa_2f, reserv_insa_3f, reserv_insa_4f, reserv_insa_5f, reserv_insa_6f, reserv_insa_7f, reserv_insa_8f, reserv_insa_9f;
    Button reserv_f_insa_prev;

    Intent intent;
    String building_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation_floor_insa);

        reserv_insa_1f = (Button)findViewById(R.id.reserv_insa_1f);
        reserv_insa_2f = (Button)findViewById(R.id.reserv_insa_2f);
        reserv_insa_3f = (Button)findViewById(R.id.reserv_insa_3f);
        reserv_insa_4f = (Button)findViewById(R.id.reserv_insa_4f);
        reserv_insa_5f = (Button)findViewById(R.id.reserv_insa_5f);
        reserv_insa_6f = (Button)findViewById(R.id.reserv_insa_6f);
        reserv_insa_7f = (Button)findViewById(R.id.reserv_insa_7f);
        reserv_insa_8f = (Button)findViewById(R.id.reserv_insa_8f);
        reserv_insa_9f = (Button)findViewById(R.id.reserv_insa_9f);

        reserv_f_insa_prev = (Button)findViewById(R.id.reserv_f_insa_prev);

        intent = getIntent();
        building_name = intent.getStringExtra("building_name");

        reserv_insa_1f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_insa.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 1);
                startActivity(intent);
            }
        });

        reserv_insa_2f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_insa.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 2);
                startActivity(intent);
            }
        });

        reserv_insa_3f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_insa.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 3);
                startActivity(intent);
            }
        });

        reserv_insa_4f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_insa.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 4);
                startActivity(intent);
            }
        });

        reserv_insa_5f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_insa.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 5);
                startActivity(intent);
            }
        });

        reserv_insa_6f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_insa.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 6);
                startActivity(intent);
            }
        });

        reserv_insa_7f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_insa.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 7);
                startActivity(intent);
            }
        });

        reserv_insa_8f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_insa.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 8);
                startActivity(intent);
            }
        });

        reserv_insa_9f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_insa.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 9);
                startActivity(intent);
            }
        });

        reserv_f_insa_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
}
