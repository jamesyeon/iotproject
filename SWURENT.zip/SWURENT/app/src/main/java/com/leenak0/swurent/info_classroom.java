package com.leenak0.swurent;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class info_classroom extends AppCompatActivity {

    Button info_c1,info_c2,info_c3,info_c4,info_c5,info_c6;
    Button info_c_prev;
    String info_building, info_floor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_classroom);

        info_c1 = (Button)findViewById(R.id.info_c1);
        info_c2 = (Button)findViewById(R.id.info_c2);
        info_c3 = (Button)findViewById(R.id.info_c3);
        info_c4 = (Button)findViewById(R.id.info_c4);
        info_c5 = (Button)findViewById(R.id.info_c5);
        info_c6 = (Button)findViewById(R.id.info_c6);
        info_c_prev = (Button)findViewById(R.id.info_c_prev);

        Intent intent = getIntent();
        info_building = intent.getStringExtra("info_building");
        info_floor = intent.getStringExtra("info_floor");

        info_c1.setText(info_floor+"01호");
        info_c2.setText(info_floor+"02호");
        info_c3.setText(info_floor+"03호");
        info_c4.setText(info_floor+"04호");
        info_c5.setText(info_floor+"05호");
        info_c6.setText(info_floor+"06호");

        info_c1.setOnClickListener(new View.OnClickListener(){ //1호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_classroom.this, info.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_c1.getText().toString());
                startActivity(intent);
            }
        });

        info_c2.setOnClickListener(new View.OnClickListener(){ //2호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_classroom.this, info.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_c2.getText().toString());
                startActivity(intent);
            }
        });

        info_c3.setOnClickListener(new View.OnClickListener(){ //3호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_classroom.this, info.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_c3.getText().toString());
                startActivity(intent);
            }
        });

        info_c4.setOnClickListener(new View.OnClickListener(){ //4호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_classroom.this, info.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_c4.getText().toString());
                startActivity(intent);
            }
        });

        info_c5.setOnClickListener(new View.OnClickListener(){ //5호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_classroom.this, info.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_c5.getText().toString());
                startActivity(intent);
            }
        });

        info_c6.setOnClickListener(new View.OnClickListener(){ //6호

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_classroom.this, info.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_c6.getText().toString());
                startActivity(intent);
            }
        });

        info_c_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
