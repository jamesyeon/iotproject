package com.leenak0.swurent;

import android.graphics.drawable.Drawable;
import android.view.View;

public class ListVO {
    public Drawable img;
    public String strTitle;
    public String strLimitnum;
    public String strTexttime;
    public View.OnClickListener onClickListener;
}
