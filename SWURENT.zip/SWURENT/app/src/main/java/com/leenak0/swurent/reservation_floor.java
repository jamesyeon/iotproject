package com.leenak0.swurent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class reservation_floor extends AppCompatActivity {

    Button reserv_6f;
    Button reserv_f_prev;
    String building_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation_floor);

        reserv_6f = (Button)findViewById(R.id.reserv_6f);
        reserv_f_prev = (Button)findViewById(R.id.reserv_f_prev);

        Intent intent = getIntent();
        building_name = intent.getStringExtra("building_name");

        reserv_6f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(reservation_floor.this, reservation_classroom.class);
                intent2.putExtra("building_name", building_name);
                startActivity(intent2);
            }
        });

        reserv_f_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}