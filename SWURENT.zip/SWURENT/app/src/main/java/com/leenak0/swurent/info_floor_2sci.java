package com.leenak0.swurent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class info_floor_2sci extends AppCompatActivity {

    Button info_2sci_B1f, info_2sci_1f, info_2sci_2f, info_2sci_3f, info_2sci_4f, info_2sci_5f, info_2sci_6f;
    Button info_f_2sci_prev;
    String info_building;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_floor_2sci);

        info_2sci_B1f = (Button)findViewById(R.id.info_2sci_B1f);
        info_2sci_1f = (Button)findViewById(R.id.info_2sci_1f);
        info_2sci_2f = (Button)findViewById(R.id.info_2sci_2f);
        info_2sci_3f = (Button)findViewById(R.id.info_2sci_3f);
        info_2sci_4f = (Button)findViewById(R.id.info_2sci_4f);
        info_2sci_5f = (Button)findViewById(R.id.info_2sci_5f);
        info_2sci_6f = (Button)findViewById(R.id.info_2sci_6f);
        info_f_2sci_prev = (Button)findViewById(R.id.info_f_2sci_prev);

        Intent intent = getIntent();
        info_building = intent.getStringExtra("info_building");

        info_2sci_B1f.setOnClickListener(new View.OnClickListener(){ //B1층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_2sci.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "B1");
                startActivity(intent);
            }
        });

        info_2sci_1f.setOnClickListener(new View.OnClickListener(){ //1층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_2sci.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "1");
                startActivity(intent);
            }
        });

        info_2sci_2f.setOnClickListener(new View.OnClickListener(){ //2층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_2sci.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "2");
                startActivity(intent);
            }
        });

        info_2sci_3f.setOnClickListener(new View.OnClickListener(){ //3층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_2sci.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "3");
                startActivity(intent);
            }
        });

        info_2sci_4f.setOnClickListener(new View.OnClickListener(){ //4층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_2sci.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "4");
                startActivity(intent);
            }
        });

        info_2sci_5f.setOnClickListener(new View.OnClickListener(){ //5층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_2sci.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "5");
                startActivity(intent);
            }
        });

        info_2sci_6f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_2sci.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "6");
                startActivity(intent);
            }
        });

        info_f_2sci_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
}
