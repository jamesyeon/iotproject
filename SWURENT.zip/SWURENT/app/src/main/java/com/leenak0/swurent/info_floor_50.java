package com.leenak0.swurent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class info_floor_50 extends AppCompatActivity {

    Button info_50_2f, info_50_3f, info_50_4f, info_50_5f, info_50_6f, info_50_7f;
    Button info_f_50_prev;
    String info_building;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_floor_50);

        info_50_2f = (Button)findViewById(R.id.info_50_2f);
        info_50_3f = (Button)findViewById(R.id.info_50_3f);
        info_50_4f = (Button)findViewById(R.id.info_50_4f);
        info_50_5f = (Button)findViewById(R.id.info_50_5f);
        info_50_6f = (Button)findViewById(R.id.info_50_6f);
        info_50_7f = (Button)findViewById(R.id.info_50_7f);
        info_f_50_prev = (Button)findViewById(R.id.info_f_50_prev);

        Intent intent = getIntent();
        info_building = intent.getStringExtra("info_building");

        info_50_2f.setOnClickListener(new View.OnClickListener(){ //2층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_50.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "2");
                startActivity(intent);
            }
        });

        info_50_3f.setOnClickListener(new View.OnClickListener(){ //3층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_50.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "3");
                startActivity(intent);
            }
        });

        info_50_4f.setOnClickListener(new View.OnClickListener(){ //4층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_50.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "4");
                startActivity(intent);
            }
        });

        info_50_5f.setOnClickListener(new View.OnClickListener(){ //5층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_50.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "5");
                startActivity(intent);
            }
        });

        info_50_6f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_50.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "6");
                startActivity(intent);
            }
        });

        info_50_7f.setOnClickListener(new View.OnClickListener(){ //7층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_50.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "7");
                startActivity(intent);
            }
        });


        info_f_50_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
