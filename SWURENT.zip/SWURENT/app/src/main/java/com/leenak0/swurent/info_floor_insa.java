package com.leenak0.swurent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class info_floor_insa extends AppCompatActivity {

    Button info_insa_1f, info_insa_2f, info_insa_3f, info_insa_4f, info_insa_5f, info_insa_6f, info_insa_7f, info_insa_8f, info_insa_9f;
    Button info_f_insa_prev;
    String info_building;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_floor_insa);

        info_insa_1f = (Button)findViewById(R.id.info_insa_1f);
        info_insa_2f = (Button)findViewById(R.id.info_insa_2f);
        info_insa_3f = (Button)findViewById(R.id.info_insa_3f);
        info_insa_4f = (Button)findViewById(R.id.info_insa_4f);
        info_insa_5f = (Button)findViewById(R.id.info_insa_5f);
        info_insa_6f = (Button)findViewById(R.id.info_insa_6f);
        info_insa_7f = (Button)findViewById(R.id.info_insa_7f);
        info_insa_8f = (Button)findViewById(R.id.info_insa_8f);
        info_insa_9f = (Button)findViewById(R.id.info_insa_9f);
        info_f_insa_prev = (Button)findViewById(R.id.info_f_insa_prev);

        Intent intent = getIntent();
        info_building = intent.getStringExtra("info_building");

        info_insa_1f.setOnClickListener(new View.OnClickListener(){ //1층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_insa.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "1");
                startActivity(intent);
            }
        });

        info_insa_2f.setOnClickListener(new View.OnClickListener(){ //2층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_insa.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "2");
                startActivity(intent);
            }
        });

        info_insa_3f.setOnClickListener(new View.OnClickListener(){ //3층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_insa.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "3");
                startActivity(intent);
            }
        });

        info_insa_4f.setOnClickListener(new View.OnClickListener(){ //4층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_insa.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "4");
                startActivity(intent);
            }
        });

        info_insa_5f.setOnClickListener(new View.OnClickListener(){ //5층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_insa.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "5");
                startActivity(intent);
            }
        });

        info_insa_6f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_insa.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "6");
                startActivity(intent);
            }
        });

        info_insa_7f.setOnClickListener(new View.OnClickListener(){ //7층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_insa.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "7");
                startActivity(intent);
            }
        });

        info_insa_8f.setOnClickListener(new View.OnClickListener(){ //8층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_insa.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "8");
                startActivity(intent);
            }
        });

        info_insa_9f.setOnClickListener(new View.OnClickListener(){ //9층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_floor_insa.this, info_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor", "9");
                startActivity(intent);
            }
        });

        info_f_insa_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
}
