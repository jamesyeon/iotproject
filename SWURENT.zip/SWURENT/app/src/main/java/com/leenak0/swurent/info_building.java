package com.leenak0.swurent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class info_building extends AppCompatActivity {

    Button info_50, info_insa, info_2sci, info_b_prev;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_building);

        info_50 = (Button)findViewById(R.id.info_50);
        info_insa = (Button)findViewById(R.id.info_insa);
        info_2sci = (Button)findViewById(R.id.info_2sci);
        info_b_prev = (Button)findViewById(R.id.info_b_prev);

        info_50.setOnClickListener(new View.OnClickListener(){ //50주년

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_building.this, info_floor_50.class);
                intent.putExtra("info_building","50주년기념관");
                startActivity(intent);
            }
        });

        info_insa.setOnClickListener(new View.OnClickListener(){ //인문사회관

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_building.this, info_floor_insa.class);
                intent.putExtra("info_building","인문사회관");
                startActivity(intent);
            }
        });

        info_2sci.setOnClickListener(new View.OnClickListener(){ //제2과학관

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(info_building.this, info_floor_2sci.class);
                intent.putExtra("info_building","제2과학관");
                startActivity(intent);
            }
        });

        info_b_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
