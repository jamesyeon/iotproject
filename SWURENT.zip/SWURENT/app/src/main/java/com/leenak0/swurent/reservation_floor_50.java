package com.leenak0.swurent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class reservation_floor_50 extends AppCompatActivity {

    Button reserv_50_2f, reserv_50_3f, reserv_50_4f, reserv_50_5f, reserv_50_6f, reserv_50_7f;
    Button reserv_f_50_prev;

    Intent intent;
    String building_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation_floor_50);

        reserv_50_2f = (Button)findViewById(R.id.reserv_50_2f);
        reserv_50_3f = (Button)findViewById(R.id.reserv_50_3f);
        reserv_50_4f = (Button)findViewById(R.id.reserv_50_4f);
        reserv_50_5f = (Button)findViewById(R.id.reserv_50_5f);
        reserv_50_6f = (Button)findViewById(R.id.reserv_50_6f);
        reserv_50_7f = (Button)findViewById(R.id.reserv_50_7f);
        reserv_f_50_prev = (Button)findViewById(R.id.reserv_f_50_prev);

        intent = getIntent();
        building_name = intent.getStringExtra("building_name");



        reserv_50_2f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_50.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 2);
                startActivity(intent);
            }
        });

        reserv_50_3f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_50.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 3);
                startActivity(intent);
            }
        });

        reserv_50_4f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_50.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 4);
                startActivity(intent);
            }
        });

        reserv_50_5f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_50.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 5);
                startActivity(intent);
            }
        });

        reserv_50_6f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_50.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 6);
                startActivity(intent);
            }
        });

        reserv_50_7f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reservation_floor_50.this, reservation_classroom.class);
                intent.putExtra("building_name", building_name);
                intent.putExtra("floor_num", 7);
                startActivity(intent);
            }
        });


        reserv_f_50_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}