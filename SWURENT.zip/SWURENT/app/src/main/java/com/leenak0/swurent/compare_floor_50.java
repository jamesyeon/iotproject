package com.leenak0.swurent;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class compare_floor_50 extends AppCompatActivity {

    Button com_50_2f, com_50_3f, com_50_4f, com_50_5f, com_50_6f, com_50_7f;
    Button com_f_50_prev;
    String info_building, info_classroom, sen1, com_building, info_floor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE); //테마 색 불러오기
        String theme = pref.getString("theme", "wine");
        if(theme=="wine")
            setTheme(R.style.wineTheme);
        else if(theme=="pink")
            setTheme(R.style.pinkTheme);
        else
            setTheme(R.style.blueTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare_floor_50);

        com_50_2f = (Button)findViewById(R.id.com_50_2f);
        com_50_3f = (Button)findViewById(R.id.com_50_3f);
        com_50_4f = (Button)findViewById(R.id.com_50_4f);
        com_50_5f = (Button)findViewById(R.id.com_50_5f);
        com_50_6f = (Button)findViewById(R.id.com_50_6f);
        com_50_7f = (Button)findViewById(R.id.com_50_7f);
        com_f_50_prev = (Button)findViewById(R.id.com_f_50_prev);

        Intent intent = getIntent();
        info_building = intent.getStringExtra("info_building");
        info_floor = intent.getStringExtra("info_floor");
        info_classroom = intent.getStringExtra("info_classroom");
        sen1 = intent.getStringExtra("sen1");
        com_building=intent.getStringExtra("com_building");

        com_50_2f.setOnClickListener(new View.OnClickListener(){ //2층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_50.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","2");
                startActivity(intent);
            }
        });

        com_50_3f.setOnClickListener(new View.OnClickListener(){ //3층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_50.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","3");
                startActivity(intent);
            }
        });

        com_50_4f.setOnClickListener(new View.OnClickListener(){ //4층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_50.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","4");
                startActivity(intent);
            }
        });

        com_50_5f.setOnClickListener(new View.OnClickListener(){ //5층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_50.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","5");
                startActivity(intent);
            }
        });

        com_50_6f.setOnClickListener(new View.OnClickListener(){ //6층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_50.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","6");
                startActivity(intent);
            }
        });

        com_50_7f.setOnClickListener(new View.OnClickListener(){ //7층

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(compare_floor_50.this, compare_classroom.class);
                intent.putExtra("info_building", info_building);
                intent.putExtra("info_floor",info_floor);
                intent.putExtra("info_classroom", info_classroom);
                intent.putExtra("sen1",sen1);
                intent.putExtra("com_building",com_building);
                intent.putExtra("com_floor","7");
                startActivity(intent);
            }
        });


        com_f_50_prev.setOnClickListener(new View.OnClickListener(){ //뒤로

            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}